# Bug Report: Campaign Event Data

## Scope
Reviewed `events.jsonl` (20,000 JSONL rows) against `expected_output.txt` (five campaign summaries, including daily delivered counts).

## Findings

### BUG-01 — Duplicate event records inflate aggregate metrics
**Severity:** High  
**Evidence:**
- `events.jsonl` contains 20,000 rows but only 19,400 distinct `event_id` values.
- There are **600 extra rows** caused by duplicated IDs.
- All duplicated-ID groups examined are exact duplicate records; no conflicting payloads were found.
- Counting every row produces inflated totals. For example, campaign A has 2,037 `sent` rows and 1,986 `delivered` rows, while the deduplicated counts are 1,987 and 1,914.

**Impact:** Any aggregation that counts raw rows overstates sent, delivered, opened, and clicked events.  
**Recommendation:** Enforce uniqueness on `event_id` (for example, a database unique constraint) and make ingestion idempotent. Deduplicate before aggregation as a defensive measure.

### BUG-02 — Delivered count exceeds sent count for campaign D
**Severity:** High  
**Evidence in `expected_output.txt` (deduplicated totals):**
- Campaign `cmp_D`: `sent=981`, `delivered=1004`.
- Delivered exceeds sent by **23**.

**Impact:** The campaign funnel is internally inconsistent if each delivered event must correspond to a previously sent message. This can produce misleading delivery rates above 100%.  
**Recommendation:** Trace campaign D's source events and confirm whether sent events are missing, delivery events are duplicated under different IDs, or the two metrics use different scopes/time windows. Add a validation that delivered does not exceed sent when both metrics represent the same cohort.

### BUG-03 — Lifecycle events often lack a preceding prerequisite event
**Severity:** High (if the event stream is intended to represent a complete per-contact lifecycle)  
**Evidence after deduplicating by `event_id` and grouping by campaign/contact:**
- **4,567** delivered events have no earlier sent event for that same campaign/contact.
- **3,091** opened events have no earlier delivered event for that same campaign/contact.
- **1,374** clicked events have no earlier delivered event for that same campaign/contact.

The check uses timestamps and requires the prerequisite event to occur at or before the event being checked.

**Impact:** Funnel sequencing and per-contact conversion analysis may be unreliable.  
**Recommendation:** Verify whether the input is a partial event export. If it is meant to be complete, validate event transitions and investigate missing or late-arriving events. If partial exports are expected, document that limitation and avoid treating these counts as definitive lifecycle violations.

## Validation notes

- All **20,000** lines parsed as valid JSON; no malformed JSONL rows were found.
- The `event_id` sequence covers `dvt_000000` through `dvt_019399` with no missing numeric IDs after deduplication.
- The campaign totals and all 35 daily delivered counts in `expected_output.txt` match the aggregates computed after deduplicating `events.jsonl` by `event_id`. This suggests the expected output applies event-ID deduplication.
- The duplicated records are exact copies, so they appear to be ingestion/replay duplicates rather than conflicting updates.

## Suggested regression checks

1. Reject or idempotently ignore a second event with an existing `event_id`.
2. Assert that aggregate metrics are calculated from unique event IDs.
3. For complete lifecycle datasets, assert `sent >= delivered` per campaign and require `sent` before `delivered`, `delivered` before `opened`, and `delivered` before `clicked` for each campaign/contact.
4. Add tests proving that replaying the same JSONL rows does not change campaign or daily aggregates.
