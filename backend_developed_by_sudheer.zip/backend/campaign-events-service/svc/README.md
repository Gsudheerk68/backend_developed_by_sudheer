# Campaign events service

Go 1.22+, standard library only (no `go get` needed).

## Run

    go run .                         # in-memory, listens on :8080
    go run . -data events.log        # same, but durable: events survive restarts
    go run . -addr :9000 -max-future 48h

Flags: `-addr`, `-data` (append-only log path; empty = in-memory only),
`-max-future` (reject timestamps further ahead than this; `0` disables).

## Test

    go test -race ./...

## Try it

    curl -s -X POST localhost:8080/events -H 'Content-Type: application/json' \
      --data-binary @seed/events.json
    curl -s localhost:8080/campaigns/cmp_summer_sale/stats
    curl -s 'localhost:8080/campaigns/cmp_summer_sale/events?limit=5&type=opened'

## API

### POST /events
Body: JSON array of events (max 4 MiB). Each element is validated on its own,
so one bad event never affects the others.

Status: `200` whenever the body was a JSON array — even if some or all events
were rejected (providers retry on non-2xx, and a rejected event can never become
valid, so a retry would be pointless). `400` not a JSON array; `413` too large;
`500` only if persisting failed (retry is correct then; nothing was applied).

    {"received":235,"accepted":211,"duplicates":15,"conflicts":3,"rejected":6,
     "problems":[{"index":27,"event_id":"evt_00212","status":"rejected","reason":"timestamp is not RFC 3339"}, ...]}

`problems` lists rejected events and conflicts (with their batch index).
Plain duplicates are only counted.

### GET /campaigns/{id}/stats
Per type: `events` (every accepted event) and `unique_contacts` (distinct
contacts). Also `rates` (delivery = unique delivered / unique sent; open and
click = unique opened or clicked / unique delivered; `null` if the denominator is
0; may exceed 1 if a funnel step arrived without the step before it), first/last
event time, `last_received_at` (freshness), and `hourly` buckets of raw events by
event timestamp (UTC). `404` if no event has ever been accepted for that campaign.

### GET /campaigns/{id}/events
Newest first by `(timestamp, event_id)`. Query: `limit` (1–500, default 50),
`type`, `cursor` (pass back `next_cursor`).

## Decisions

| Question | Decision |
|---|---|
| Same event? | Same `event_id`. Retry = same campaign, contact, type, timestamp (metadata ignored). |
| Same id, different content | `conflict`: first write wins, logged, not counted. |
| Reject | not an object, wrong field type, empty/missing `event_id`/`campaign_id`/`contact_id`, unknown type, non-RFC 3339 timestamp, timestamp > `max-future` ahead, non-object or >4 KiB metadata, IDs > 128 bytes. |
| Normalise | trim whitespace on IDs; lowercase `type`; convert timestamps to UTC. |
| "Opened" | Both: raw events and distinct contacts. Arrival order never matters. |
| Storage | In-memory maps + per-campaign aggregates updated on write; optional JSONL log, written before memory is updated. |
| Concurrency | One RWMutex; duplicate check and insert happen in the same critical section. |

## Known limits
- Memory grows with events and distinct contacts (fine for the stated volume; see NOTES.md for the scale discussion).
- "First write wins" on conflicts depends on arrival order, which providers don't guarantee.
- The log has no rotation or compaction, and replay on start is single-threaded.
- No auth on the webhook.
