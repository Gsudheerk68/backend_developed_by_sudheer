package main

import (
	"encoding/json"
	"time"
)

// Event types, in the fixed order used for the per-type arrays in the store.
var eventTypes = [4]string{"sent", "delivered", "opened", "clicked"}

func typeIndex(t string) int {
	for i, v := range eventTypes {
		if v == t {
			return i
		}
	}
	return -1
}

// Event is a validated, normalised event as stored.
type Event struct {
	EventID    string          `json:"event_id"`
	CampaignID string          `json:"campaign_id"`
	ContactID  string          `json:"contact_id"`
	Type       string          `json:"type"`
	Timestamp  time.Time       `json:"timestamp"`          // when it happened at the provider (UTC)
	ReceivedAt time.Time       `json:"received_at"`        // when we accepted it
	Metadata   json.RawMessage `json:"metadata,omitempty"` // opaque JSON object, optional
}

// Outcome statuses for one event in a POST /events batch.
const (
	StatusAccepted  = "accepted"
	StatusDuplicate = "duplicate" // same event_id, same content: a retry
	StatusConflict  = "conflict"  // same event_id, different content: first write wins
	StatusRejected  = "rejected"  // invalid; will never become valid on retry
)

// Outcome is the result for one element of a batch.
type Outcome struct {
	Index   int    `json:"index"`
	EventID string `json:"event_id,omitempty"`
	Status  string `json:"status"`
	Reason  string `json:"reason,omitempty"`
}
