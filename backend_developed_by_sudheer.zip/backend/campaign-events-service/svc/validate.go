package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strings"
	"time"
)

const (
	maxIDLen         = 128
	maxMetadataBytes = 4096
)

// rawEvent mirrors the wire format. Fields are plain strings so that a wrong
// JSON type (e.g. a number for event_id) fails only this one event.
type rawEvent struct {
	EventID    string          `json:"event_id"`
	CampaignID string          `json:"campaign_id"`
	ContactID  string          `json:"contact_id"`
	Type       string          `json:"type"`
	Timestamp  string          `json:"timestamp"`
	Metadata   json.RawMessage `json:"metadata"`
}

// parseEvent validates and normalises one batch element. On failure it
// returns a human-readable reason and the zero Event.
//
// Normalisation (deliberate, lossless in meaning): surrounding whitespace on
// IDs is trimmed; type is trimmed and lowercased ("OPENED" -> "opened");
// timestamps with any RFC 3339 offset are converted to UTC.
//
// Rejection: not an object, wrong field types, missing/empty required fields,
// over-long IDs, unknown type, unparseable timestamp, timestamp further in the
// future than maxFuture (0 disables), metadata that is not an object or is
// oversized.
func parseEvent(item json.RawMessage, now time.Time, maxFuture time.Duration) (Event, string) {
	trimmed := bytes.TrimSpace(item)
	if len(trimmed) == 0 || trimmed[0] != '{' {
		return Event{}, "event must be a JSON object"
	}
	var r rawEvent
	if err := json.Unmarshal(trimmed, &r); err != nil {
		return Event{}, "wrong field type: " + shortErr(err)
	}

	e := Event{
		EventID:    strings.TrimSpace(r.EventID),
		CampaignID: strings.TrimSpace(r.CampaignID),
		ContactID:  strings.TrimSpace(r.ContactID),
		Type:       strings.ToLower(strings.TrimSpace(r.Type)),
	}
	for _, f := range []struct{ name, val string }{
		{"event_id", e.EventID}, {"campaign_id", e.CampaignID}, {"contact_id", e.ContactID},
	} {
		if f.val == "" {
			return Event{}, f.name + " is required"
		}
		if len(f.val) > maxIDLen {
			return Event{}, fmt.Sprintf("%s longer than %d bytes", f.name, maxIDLen)
		}
	}
	if typeIndex(e.Type) < 0 {
		return Event{}, fmt.Sprintf("unknown type %q (want sent|delivered|opened|clicked)", r.Type)
	}

	if strings.TrimSpace(r.Timestamp) == "" {
		return Event{}, "timestamp is required"
	}
	ts, err := time.Parse(time.RFC3339, strings.TrimSpace(r.Timestamp))
	if err != nil {
		return Event{}, "timestamp is not RFC 3339"
	}
	e.Timestamp = ts.UTC()
	if maxFuture > 0 && e.Timestamp.After(now.Add(maxFuture)) {
		return Event{}, "timestamp is in the future"
	}

	if md := bytes.TrimSpace(r.Metadata); len(md) > 0 && !bytes.Equal(md, []byte("null")) {
		if md[0] != '{' {
			return Event{}, "metadata must be a JSON object"
		}
		if len(md) > maxMetadataBytes {
			return Event{}, fmt.Sprintf("metadata larger than %d bytes", maxMetadataBytes)
		}
		var buf bytes.Buffer
		if err := json.Compact(&buf, md); err != nil {
			return Event{}, "metadata is not valid JSON"
		}
		e.Metadata = buf.Bytes()
	}
	return e, ""
}

func shortErr(err error) string {
	if ute, ok := err.(*json.UnmarshalTypeError); ok {
		return fmt.Sprintf("%s must be %s", ute.Field, ute.Type)
	}
	return "invalid JSON"
}
