package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

var testNow = time.Date(2026, 8, 11, 0, 0, 0, 0, time.UTC)

func newTestServer(t *testing.T, store *Store) *httptest.Server {
	t.Helper()
	s := NewServer(store, 24*time.Hour)
	s.now = func() time.Time { return testNow }
	ts := httptest.NewServer(s.Routes())
	t.Cleanup(ts.Close)
	return ts
}

func post(t *testing.T, ts *httptest.Server, body string) (int, ingestResponse) {
	t.Helper()
	resp, err := http.Post(ts.URL+"/events", "application/json", strings.NewReader(body))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	var out ingestResponse
	json.NewDecoder(resp.Body).Decode(&out)
	return resp.StatusCode, out
}

func getStats(t *testing.T, ts *httptest.Server, id string) Stats {
	t.Helper()
	resp, err := http.Get(ts.URL + "/campaigns/" + id + "/stats")
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		t.Fatalf("stats status %d", resp.StatusCode)
	}
	var st Stats
	json.NewDecoder(resp.Body).Decode(&st)
	return st
}

func ev(id, camp, contact, typ, ts string) string {
	return fmt.Sprintf(`{"event_id":%q,"campaign_id":%q,"contact_id":%q,"type":%q,"timestamp":%q}`, id, camp, contact, typ, ts)
}

// A retry must never change a number, and must still get a 2xx.
func TestDuplicateRetryDoesNotDoubleCount(t *testing.T) {
	ts := newTestServer(t, NewStore())
	body := "[" + ev("e1", "c", "u1", "delivered", "2026-08-10T10:00:00Z") + "]"
	_, first := post(t, ts, body)
	code, second := post(t, ts, body)
	if first.Accepted != 1 || code != 200 || second.Duplicates != 1 || second.Accepted != 0 {
		t.Fatalf("first=%+v second=%+v code=%d", first, second, code)
	}
	if got := getStats(t, ts, "c").Totals.Delivered.Events; got != 1 {
		t.Fatalf("delivered events = %d, want 1", got)
	}
}

// Same event_id with different content: first write wins, reported as a conflict, numbers unchanged.
func TestConflictKeepsFirst(t *testing.T) {
	ts := newTestServer(t, NewStore())
	post(t, ts, "["+ev("e1", "c", "u1", "sent", "2026-08-10T10:00:00Z")+"]")
	_, r := post(t, ts, "["+ev("e1", "c", "u1", "clicked", "2026-08-10T10:00:00Z")+"]")
	if r.Conflicts != 1 || r.Accepted != 0 || len(r.Problems) != 1 || r.Problems[0].Status != StatusConflict {
		t.Fatalf("%+v", r)
	}
	st := getStats(t, ts, "c")
	if st.Totals.Sent.Events != 1 || st.Totals.Clicked.Events != 0 {
		t.Fatalf("%+v", st.Totals)
	}
}

// One malformed event must not take down the others around it, whatever way it is malformed.
func TestBadEventDoesNotSinkBatch(t *testing.T) {
	ts := newTestServer(t, NewStore())
	body := `[` + ev("e1", "c", "u1", "sent", "2026-08-10T10:00:00Z") + `,
	  {"event_id": 123, "campaign_id":"c","contact_id":"u2","type":"sent","timestamp":"2026-08-10T10:00:00Z"},
	  "just a string", null, 42,
	  {"event_id":"e3","campaign_id":"c","contact_id":"u3","type":"sent","timestamp":"yesterday"},
	  {"event_id":"e4","campaign_id":"c","contact_id":"u4","type":"spam_report","timestamp":"2026-08-10T10:00:00Z"},
	  {"event_id":"e5","campaign_id":"c","type":"sent","timestamp":"2026-08-10T10:00:00Z"},
	  {"event_id":"e6","campaign_id":"c","contact_id":"u6","type":"sent","timestamp":"2099-01-01T00:00:00Z"},
	  {"event_id":"e7","campaign_id":"c","contact_id":"u7","type":"sent","timestamp":"2026-08-10T10:00:00Z","metadata":"nope"},
	  ` + ev("e2", "c", "u2", "sent", "2026-08-10T10:00:00Z") + `]`
	code, r := post(t, ts, body)
	if code != 200 || r.Received != 11 || r.Accepted != 2 || r.Rejected != 9 {
		t.Fatalf("code=%d %+v", code, r)
	}
	if got := getStats(t, ts, "c").Totals.Sent.Events; got != 2 {
		t.Fatalf("sent = %d, want 2", got)
	}
}

func TestNotAnArrayIs400(t *testing.T) {
	ts := newTestServer(t, NewStore())
	for _, b := range []string{`{"event_id":"x"}`, `not json`, ``, `[] []`} {
		if code, _ := post(t, ts, b); code != 400 {
			t.Errorf("body %q: status %d, want 400", b, code)
		}
	}
}

func TestNormalisation(t *testing.T) {
	ts := newTestServer(t, NewStore())
	body := `[{"event_id":" e1 ","campaign_id":"c","contact_id":"u1","type":"OPENED","timestamp":"2026-08-10T15:30:00+05:30"}]`
	if _, r := post(t, ts, body); r.Accepted != 1 {
		t.Fatalf("%+v", r)
	}
	st := getStats(t, ts, "c")
	if st.Totals.Opened.Events != 1 || st.Hourly[0].Hour != time.Date(2026, 8, 10, 10, 0, 0, 0, time.UTC) {
		t.Fatalf("%+v", st)
	}
}

// "Opened" has two honest meanings; we report both and they must differ correctly.
func TestRawVersusUniqueOpens(t *testing.T) {
	ts := newTestServer(t, NewStore())
	var evs []string
	for i := 0; i < 5; i++ {
		evs = append(evs, ev(fmt.Sprintf("o%d", i), "c", "u1", "opened", fmt.Sprintf("2026-08-10T10:0%d:00Z", i)))
	}
	evs = append(evs, ev("o9", "c", "u2", "opened", "2026-08-10T11:00:00Z"))
	post(t, ts, "["+strings.Join(evs, ",")+"]")
	o := getStats(t, ts, "c").Totals.Opened
	if o.Events != 6 || o.UniqueContacts != 2 {
		t.Fatalf("%+v", o)
	}
}

// Arrival order must not matter: an open before its delivery, or any shuffle, gives identical stats.
func TestOutOfOrderArrivalSameStats(t *testing.T) {
	a := []string{
		ev("1", "c", "u1", "sent", "2026-08-10T10:00:00Z"),
		ev("2", "c", "u1", "delivered", "2026-08-10T10:00:05Z"),
		ev("3", "c", "u1", "opened", "2026-08-10T10:05:00Z"),
		ev("4", "c", "u1", "clicked", "2026-08-10T10:06:00Z"),
	}
	b := []string{a[3], a[2], a[0], a[1]}
	t1, t2 := newTestServer(t, NewStore()), newTestServer(t, NewStore())
	post(t, t1, "["+strings.Join(a, ",")+"]")
	post(t, t2, "["+strings.Join(b, ",")+"]")
	s1, s2 := getStats(t, t1, "c"), getStats(t, t2, "c")
	s1.LastReceivedAt, s2.LastReceivedAt = time.Time{}, time.Time{}
	j1, _ := json.Marshal(s1)
	j2, _ := json.Marshal(s2)
	if string(j1) != string(j2) {
		t.Fatalf("\n%s\n%s", j1, j2)
	}
}

// Many concurrent requests carrying the same events: each event is accepted exactly once. Run with -race.
func TestConcurrentIdenticalBatches(t *testing.T) {
	store := NewStore()
	ts := newTestServer(t, store)
	var evs []string
	for i := 0; i < 200; i++ {
		evs = append(evs, ev(fmt.Sprintf("e%03d", i), "c", fmt.Sprintf("u%d", i%50), "opened", "2026-08-10T10:00:00Z"))
	}
	body := "[" + strings.Join(evs, ",") + "]"

	var wg sync.WaitGroup
	var mu sync.Mutex
	accepted, dups := 0, 0
	for g := 0; g < 20; g++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			_, r := post(t, ts, body)
			mu.Lock()
			accepted += r.Accepted
			dups += r.Duplicates
			mu.Unlock()
		}()
	}
	wg.Wait()
	if accepted != 200 || dups != 200*19 {
		t.Fatalf("accepted=%d dups=%d", accepted, dups)
	}
	o := getStats(t, ts, "c").Totals.Opened
	if o.Events != 200 || o.UniqueContacts != 50 {
		t.Fatalf("%+v", o)
	}
}

// The provided seed file must be survivable, with exactly the outcomes we documented.
func TestSeedFile(t *testing.T) {
	raw, err := os.ReadFile("seed/events.json")
	if err != nil {
		t.Skip("seed file not present")
	}
	ts := newTestServer(t, NewStore())
	code, r := post(t, ts, string(raw))
	if code != 200 || r.Received != 235 || r.Accepted != 211 || r.Duplicates != 15 || r.Conflicts != 3 || r.Rejected != 6 {
		t.Fatalf("code=%d %+v", code, r)
	}
	want := map[string]Totals{
		"cmp_summer_sale": {TypeCount{40, 40}, TypeCount{35, 35}, TypeCount{28, 20}, TypeCount{12, 12}},
		"cmp_welcome":     {TypeCount{20, 20}, TypeCount{19, 18}, TypeCount{20, 12}, TypeCount{3, 3}},
		"cmp_winback":     {TypeCount{12, 12}, TypeCount{11, 11}, TypeCount{7, 6}, TypeCount{4, 4}},
	}
	for id, w := range want {
		if got := getStats(t, ts, id).Totals; got != w {
			t.Errorf("%s: got %+v want %+v", id, got, w)
		}
	}
	// Loading the same file again must change nothing.
	_, again := post(t, ts, string(raw))
	if again.Accepted != 0 {
		t.Fatalf("second load accepted %d", again.Accepted)
	}
}

func TestPersistenceReplay(t *testing.T) {
	path := filepath.Join(t.TempDir(), "events.log")
	s1, err := OpenStore(path)
	if err != nil {
		t.Fatal(err)
	}
	ts1 := newTestServer(t, s1)
	post(t, ts1, "["+ev("e1", "c", "u1", "sent", "2026-08-10T10:00:00Z")+","+ev("e2", "c", "u1", "opened", "2026-08-10T10:01:00Z")+"]")
	s1.Close()
	// simulate a torn final line from a crash
	f, _ := os.OpenFile(path, os.O_APPEND|os.O_WRONLY, 0o644)
	f.WriteString(`{"event_id":"e3","campaig`)
	f.Close()

	s2, err := OpenStore(path)
	if err != nil {
		t.Fatal(err)
	}
	defer s2.Close()
	ts2 := newTestServer(t, s2)
	st := getStats(t, ts2, "c")
	if st.Totals.Sent.Events != 1 || st.Totals.Opened.Events != 1 {
		t.Fatalf("%+v", st.Totals)
	}
	// replayed events are still deduped; new ones still work after the torn line
	_, r := post(t, ts2, "["+ev("e1", "c", "u1", "sent", "2026-08-10T10:00:00Z")+","+ev("e4", "c", "u2", "sent", "2026-08-10T10:02:00Z")+"]")
	if r.Duplicates != 1 || r.Accepted != 1 {
		t.Fatalf("%+v", r)
	}
	s2.Close()
	s3, _ := OpenStore(path)
	defer s3.Close()
	if st, _ := s3.Stats("c"); st.Totals.Sent.Events != 2 {
		t.Fatalf("after second restart: %+v", st.Totals)
	}
}

func TestPaginationWalksEverythingOnce(t *testing.T) {
	ts := newTestServer(t, NewStore())
	var evs []string
	for i := 0; i < 25; i++ { // include equal timestamps to exercise the event_id tie-break
		evs = append(evs, ev(fmt.Sprintf("e%02d", i), "c", "u1", "opened", fmt.Sprintf("2026-08-10T10:%02d:00Z", i/3)))
	}
	post(t, ts, "["+strings.Join(evs, ",")+"]")

	seen := map[string]bool{}
	cur, pages := "", 0
	var prev time.Time
	for {
		url := ts.URL + "/campaigns/c/events?limit=10"
		if cur != "" {
			url += "&cursor=" + cur
		}
		resp, _ := http.Get(url)
		var lr listResponse
		json.NewDecoder(resp.Body).Decode(&lr)
		resp.Body.Close()
		pages++
		for _, e := range lr.Events {
			if seen[e.EventID] {
				t.Fatalf("%s returned twice", e.EventID)
			}
			seen[e.EventID] = true
			if !prev.IsZero() && e.Timestamp.After(prev) {
				t.Fatalf("not newest-first")
			}
			prev = e.Timestamp
		}
		if lr.NextCursor == "" {
			break
		}
		cur = lr.NextCursor
	}
	if len(seen) != 25 || pages != 3 {
		t.Fatalf("saw %d events in %d pages", len(seen), pages)
	}
}

func TestUnknownCampaign404(t *testing.T) {
	ts := newTestServer(t, NewStore())
	for _, p := range []string{"/campaigns/nope/stats", "/campaigns/nope/events"} {
		resp, _ := http.Get(ts.URL + p)
		resp.Body.Close()
		if resp.StatusCode != 404 {
			t.Errorf("%s: %d", p, resp.StatusCode)
		}
	}
}
