package main

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"syscall"
	"time"
)

const maxBodyBytes = 4 << 20 // 4 MiB per POST /events

type Server struct {
	store     *Store
	maxFuture time.Duration
	now       func() time.Time // injectable for tests
}

func main() {
	addr := flag.String("addr", ":8080", "listen address")
	data := flag.String("data", "", "path of append-only event log for durability (empty = in-memory only)")
	maxFuture := flag.Duration("max-future", 24*time.Hour, "reject events timestamped further in the future than this (0 disables)")
	flag.Parse()

	store, err := OpenStore(*data)
	if err != nil {
		log.Fatal(err)
	}
	defer store.Close()

	srv := &http.Server{
		Addr:              *addr,
		Handler:           NewServer(store, *maxFuture).Routes(),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       30 * time.Second,
		WriteTimeout:      30 * time.Second,
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	go func() {
		<-ctx.Done()
		sc, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		srv.Shutdown(sc)
	}()
	fmt.Printf("listening on %s (persistence: %q)\n", *addr, *data)
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Fatal(err)
	}
}

func NewServer(store *Store, maxFuture time.Duration) *Server {
	return &Server{store: store, maxFuture: maxFuture, now: time.Now}
}

func (s *Server) Routes() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /events", s.handlePostEvents)
	mux.HandleFunc("GET /campaigns/{campaignID}/stats", s.handleGetStats)
	mux.HandleFunc("GET /campaigns/{campaignID}/events", s.handleListEvents)
	return mux
}

type ingestResponse struct {
	Received   int       `json:"received"`
	Accepted   int       `json:"accepted"`
	Duplicates int       `json:"duplicates"`
	Conflicts  int       `json:"conflicts"`
	Rejected   int       `json:"rejected"`
	Problems   []Outcome `json:"problems"` // everything that was not a clean accept or a plain duplicate
}

// handlePostEvents ingests a JSON array of events.
//
// Status codes: 200 whenever the body was a JSON array, even if some or all
// events were rejected — providers retry on non-2xx, and a rejected event will
// never become valid, so asking for a retry would only cause a retry storm.
// Per-event outcomes are in the body. 400 if the body is not a JSON array,
// 413 if it is too large, 500 only if we failed to persist (retry is correct).
func (s *Server) handlePostEvents(w http.ResponseWriter, r *http.Request) {
	r.Body = http.MaxBytesReader(w, r.Body, maxBodyBytes)
	dec := json.NewDecoder(r.Body)
	var items []json.RawMessage // decode per element so one bad event can't sink the batch
	if err := dec.Decode(&items); err != nil {
		var mbe *http.MaxBytesError
		if errors.As(err, &mbe) {
			writeError(w, http.StatusRequestEntityTooLarge, fmt.Sprintf("body larger than %d bytes", maxBodyBytes))
			return
		}
		writeError(w, http.StatusBadRequest, "body must be a JSON array of events")
		return
	}
	if _, err := dec.Token(); err != io.EOF {
		writeError(w, http.StatusBadRequest, "unexpected data after the JSON array")
		return
	}

	now := s.now().UTC()
	resp := ingestResponse{Received: len(items), Problems: []Outcome{}}
	valid := make([]Event, 0, len(items))
	origIdx := make([]int, 0, len(items))
	for i, it := range items {
		e, reason := parseEvent(it, now, s.maxFuture)
		if reason != "" {
			resp.Rejected++
			resp.Problems = append(resp.Problems, Outcome{Index: i, EventID: peekEventID(it), Status: StatusRejected, Reason: reason})
			continue
		}
		valid = append(valid, e)
		origIdx = append(origIdx, i)
	}

	outcomes, err := s.store.Ingest(valid, now)
	if err != nil {
		log.Printf("ingest failed: %v", err)
		writeError(w, http.StatusInternalServerError, "could not persist events; please retry")
		return
	}
	for j, o := range outcomes {
		switch o.Status {
		case StatusAccepted:
			resp.Accepted++
		case StatusDuplicate:
			resp.Duplicates++
		case StatusConflict:
			resp.Conflicts++
			o.Index = origIdx[j]
			resp.Problems = append(resp.Problems, o)
		}
	}
	writeJSON(w, http.StatusOK, resp)
}

// peekEventID best-effort extracts event_id from a rejected item for the report.
func peekEventID(it json.RawMessage) string {
	var p struct {
		EventID string `json:"event_id"`
	}
	if json.Unmarshal(it, &p) != nil {
		return ""
	}
	return p.EventID
}

func (s *Server) handleGetStats(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("campaignID")
	st, ok := s.store.Stats(id)
	if !ok {
		writeError(w, http.StatusNotFound, "no events received for campaign "+id)
		return
	}
	writeJSON(w, http.StatusOK, st)
}

type listResponse struct {
	CampaignID string  `json:"campaign_id"`
	Events     []Event `json:"events"`
	NextCursor string  `json:"next_cursor,omitempty"`
}

// handleListEvents: newest-first by event timestamp, cursor-paginated.
// Query: limit (default 50, max 500), cursor (from next_cursor), type.
func (s *Server) handleListEvents(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("campaignID")
	q := r.URL.Query()
	limit := 50
	if v := q.Get("limit"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 || n > 500 {
			writeError(w, http.StatusBadRequest, "limit must be an integer 1-500")
			return
		}
		limit = n
	}
	typ := strings.ToLower(q.Get("type"))
	if typ != "" && typeIndex(typ) < 0 {
		writeError(w, http.StatusBadRequest, "unknown type filter")
		return
	}
	var after *cursor
	if v := q.Get("cursor"); v != "" {
		c, err := decodeCursor(v)
		if err != nil {
			writeError(w, http.StatusBadRequest, "invalid cursor")
			return
		}
		after = &c
	}
	evs, next, found := s.store.List(id, typ, limit, after)
	if !found {
		writeError(w, http.StatusNotFound, "no events received for campaign "+id)
		return
	}
	resp := listResponse{CampaignID: id, Events: evs}
	if resp.Events == nil {
		resp.Events = []Event{}
	}
	if next != nil {
		resp.NextCursor = next.encode()
	}
	writeJSON(w, http.StatusOK, resp)
}

// cursor is the (timestamp, event_id) position of the last item returned.
type cursor struct {
	ts time.Time
	id string
}

func (c cursor) encode() string {
	return base64.RawURLEncoding.EncodeToString([]byte(strconv.FormatInt(c.ts.UnixNano(), 10) + "|" + c.id))
}

func decodeCursor(s string) (cursor, error) {
	b, err := base64.RawURLEncoding.DecodeString(s)
	if err != nil {
		return cursor{}, err
	}
	ns, id, ok := strings.Cut(string(b), "|")
	if !ok {
		return cursor{}, errors.New("bad cursor")
	}
	n, err := strconv.ParseInt(ns, 10, 64)
	if err != nil {
		return cursor{}, err
	}
	return cursor{time.Unix(0, n).UTC(), id}, nil
}

func writeError(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]string{"error": msg})
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	if err := json.NewEncoder(w).Encode(v); err != nil {
		log.Printf("writeJSON: %v", err)
	}
}
