# NOTES.md

Written before any code. Plain and honest; I expect some of this to change once I look at the seed data.

## 1. My interpretation of the problem

- Relay hands messages to third-party providers. Providers call our webhook as things happen to each message (sent, delivered, opened, clicked). I own the service that ingests those events and answers dashboard questions per campaign.
- The hard part is not the CRUD. It is correctness under messy input: providers retry (duplicates), events arrive late and out of order, and some payloads will be malformed. The numbers on the dashboard must stay trustworthy through all of that.
- Ingestion must be idempotent and must tolerate a bad event without hurting its batch. Stats must not depend on arrival order.
- Scale today is small (a few thousand events/day, ~50 campaigns) but growing, so I want a design that is simple now and doesn't paint us into a corner (indexed aggregates, atomic dedupe, no in-process-only state that breaks with a second instance).

## 2. Assumptions

- `event_id` is unique per event, so it is the dedupe key. The payload has no provider field, so I assume IDs don't collide across providers. If they can, the key needs to become `(provider, event_id)`.
- A repeat of an `event_id` is a duplicate even if the payload differs. I keep the first one, and log the mismatch so it is visible rather than silent.
- `timestamp` is when it happened at the provider, so it is the right axis for any time-based view. Arrival time is stored separately for debugging.
- Valid types are exactly `sent`, `delivered`, `opened`, `clicked`. Anything else is rejected.
- `campaign_id`, `contact_id`, `event_id`, `type` and `timestamp` are required. `metadata` is optional and stored as-is (size-limited).
- A (campaign, contact) pair is my proxy for "one recipient". The payload has no `message_id`, so I can't distinguish two messages sent to the same contact in one campaign.
- Events for a campaign I have never seen are accepted. There is no campaign registry in the brief, and rejecting would drop real data.
- Stats are allowed to change after the fact, because late events are legitimate. "Live" means eventually consistent within seconds, not frozen.
- Single node; in-memory state plus an append-only log is enough. No auth on the webhook for this exercise, but I'd flag it.

## 3. Ambiguities I noticed in the brief

- **What makes two events "the same"?** `event_id` alone? `event_id` plus provider? The same (contact, type, campaign) at a different `event_id`? The brief only says providers retry, which suggests `event_id`, but a provider could also send the same real-world open twice with different IDs.
- **What does "opened" mean?** Total open events, or distinct contacts who opened? One person opening an email five times is five events but one engaged recipient. "How many were opened" reads like a count of messages/recipients, not events.
- **Funnel consistency.** If `opened` arrives with no `delivered` (out of order or never), does it count as delivered? Do I infer missing steps, or report exactly what was received? Can `opened` exceed `delivered` on the dashboard?
- **Time.** Does the dashboard need a time series, a "last hour" window, or only totals? Is "recent" by event timestamp or arrival time?
- **Channels.** Email, SMS and push are mentioned, but there is no channel field. Do stats need a per-channel breakdown? Does `opened` even apply to SMS?
- **Bad data.** What counts as invalid: unknown type, missing field, future timestamp, ancient timestamp, empty IDs? Does the provider need to know exactly which events failed?
- **Response semantics.** What status code for a batch that is partly good? What should a duplicate return? Providers retry on non-2xx, so a wrong choice can cause retry storms.
- **Batch limits.** The brief says "a JSON array" but not how large. Is there a maximum?
- **Unknown campaigns / contacts.** Accept or reject?
- **Retention and growth.** Do we keep raw events forever? Is "growing" 10x or 1000x?
- **Is "sent" our event or the provider's?** Relay hands off the message, but `sent` comes from the provider. Are those the same moment?

## 4. Questions I'd ask the PM

1. For the dashboard, is "opened" the number of open events or the number of distinct people who opened? Can we show both?
2. Should the dashboard show only totals, or also trends over time (e.g. per hour)? Which timestamp should drive that?
3. If we receive an open before a delivery, should the delivered count include that message?
4. Is there a message ID anywhere? Can one contact receive more than one message in a campaign?
5. Do you need a breakdown by channel (email / SMS / push)?
6. Can two providers ever send the same `event_id`? Is there a provider identifier we can rely on?
7. What should happen to events that fail validation: dropped, stored for review, or reported back to the provider?
8. How fresh does "live" need to be: seconds, or is a minute fine?
9. What does "growing" mean in numbers, and for how long do we need to retain raw events?
10. Is the webhook authenticated today? Do providers sign requests?

## 5. Priorities, in order

1. **Ingest correctness (first).** Per-event decoding so one bad event never drops the batch. Strict validation. Atomic dedupe: the duplicate check and the insert happen in one critical section, which is also what makes concurrent requests safe. (In SQL this would be a unique constraint plus `INSERT ... ON CONFLICT DO NOTHING`.)
2. **Stats endpoint.** Per campaign: for each type, both raw event count and unique-contact count, computed with indexed `GROUP BY`. Independent of arrival order. Also return first/last event timestamps so the dashboard can tell how fresh the data is.
3. **Clear API contract.** Per-event results in the ingest response (`accepted`, `duplicate`, `rejected` with a reason). Duplicates return success so providers stop retrying. Whole-request failure (unparseable body, oversized) returns 4xx.
4. **Tests on the scary behaviour.** Duplicate delivery, concurrent identical batches, mixed good/bad batch, out-of-order arrival, and loading the seed file without crashing.
5. **Seed-file check.** Run the seed data early to learn what mess it contains, and revise assumptions here if I'm wrong.
6. **Only if time remains:** `GET /campaigns/{id}/events` with cursor pagination, ordered by `(timestamp, event_id)`.

**Deliberately not doing:** UI, auth, multi-provider keying, inferred funnel steps, retention jobs. I'll list these as known gaps and say what I'd do about each.

---

## Part 2: what the seed data showed, and what I decided

I loaded `seed/events.json` (235 records) before finalising decisions. What is in it:

- **10 retries with identical content** (some sent 3 times); 15 duplicate lines in total. Accepted once, later copies reported as `duplicate`.
- **3 event_ids reused with different content** (same id, different `type`). These are not retries. First write wins, the rest are reported as `conflict` and logged. Caveat: "first" means first to arrive, and the seed is shuffled, so a different arrival order would keep a different version. I can't tell from the data which one is true, which is a question for the provider.
- **6 records rejected:** empty `event_id`, missing `contact_id`, empty `contact_id`, timestamp `not-a-time`, timestamp `10-08-2026 09:00` (ambiguous day/month, no zone, so I refuse to guess), and type `spam_report`.
- **1 record normalised:** type `OPENED` becomes `opened`. Case is cosmetic, and dropping a real open over capitalisation would undercount.
- Result: 211 accepted, 15 duplicates, 3 conflicts, 6 rejected. I checked these numbers with a separate Python script rather than trusting my own Go code.

Decisions I would defend in the interview:

- **200 even when events are rejected.** Providers retry on non-2xx; a malformed event never becomes valid, so asking for a retry only creates a retry storm. Details are in the body.
- **Storage:** in-memory maps and per-campaign aggregates (counts, distinct-contact sets, hourly buckets) updated at write time, so reading stats never scans events. Optional append-only log for restarts, written before memory is updated so a failed write never leaves us claiming to have stored something. I chose this over SQLite because I could not add a driver in my environment, and at a few thousand events/day it is sufficient. The trade-off is memory growth and no ad-hoc queries.
- **Stats report both raw events and unique contacts** for every type, because "how many opened" is ambiguous. I did not infer missing funnel steps: an open with no delivery is counted as an open, and rates can therefore exceed 1.
- **Unknown campaign on GET returns 404** rather than zeros, so a typo in a dashboard config is visible. The cost is that a brand-new campaign with no events yet also 404s; the dashboard should treat that as "no data yet".
- **Future-dated events are rejected** (default more than 24h ahead) because they would pollute `last_event_at` and the hourly buckets. Old events are never rejected, since late arrival is normal. The window is a flag because it depends on a wall clock I cannot control.

Tests (`go test -race ./...`) cover the behaviour I would be most embarrassed to break: retries not double counting, conflicts, one bad event not sinking a batch, 20 concurrent identical batches accepting each event exactly once, arrival-order independence, raw vs unique opens, log replay after a torn write, pagination, and the seed file with exact expected numbers. I also broke the dedupe on purpose to confirm those tests fail.
