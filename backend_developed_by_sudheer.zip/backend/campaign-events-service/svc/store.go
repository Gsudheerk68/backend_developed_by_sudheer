package main

import (
	"bufio"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"os"
	"sort"
	"sync"
	"time"
)

// Store keeps every accepted event in memory, indexed by event_id (the dedupe
// key), plus incrementally maintained per-campaign aggregates so reading stats
// never scans events. One RWMutex guards everything: ingestion is a short
// critical section, so at this volume contention is irrelevant, and a single
// lock makes "check duplicate, then insert" trivially atomic.
//
// Optional durability: accepted events are appended to a JSONL log and
// replayed on start. The log is written *before* memory is updated, so a
// failed write never leaves us claiming to have stored something we haven't.
type Store struct {
	mu        sync.RWMutex
	byID      map[string]*Event
	campaigns map[string]*campaign
	log       *eventLog
}

type campaign struct {
	raw      [4]int                 // events per type (duplicates already excluded)
	uniq     [4]map[string]struct{} // distinct contact_ids per type
	hourly   map[int64]*[4]int      // events per type per UTC hour, by event timestamp
	first    time.Time
	last     time.Time
	lastRecv time.Time
	events   []*Event // sorted ascending by (timestamp, event_id)
}

func NewStore() *Store {
	return &Store{byID: map[string]*Event{}, campaigns: map[string]*campaign{}}
}

// OpenStore creates a store backed by an append-only log at path, replaying
// anything already there. An empty path means purely in-memory.
func OpenStore(path string) (*Store, error) {
	s := NewStore()
	if path == "" {
		return s, nil
	}
	if f, err := os.Open(path); err == nil {
		sc := bufio.NewScanner(f)
		sc.Buffer(make([]byte, 1<<20), 1<<20)
		n, bad := 0, 0
		for sc.Scan() {
			var e Event
			if err := json.Unmarshal(sc.Bytes(), &e); err != nil || e.EventID == "" || typeIndex(e.Type) < 0 {
				bad++ // e.g. a torn final line after a crash
				continue
			}
			if _, dup := s.byID[e.EventID]; !dup {
				s.apply(&e)
				n++
			}
		}
		f.Close()
		if err := sc.Err(); err != nil {
			return nil, fmt.Errorf("replay %s: %w", path, err)
		}
		log.Printf("replayed %d events from %s (%d unreadable lines skipped)", n, path, bad)
	} else if !errors.Is(err, os.ErrNotExist) {
		return nil, err
	}
	l, err := openLog(path)
	if err != nil {
		return nil, err
	}
	s.log = l
	return s, nil
}

func (s *Store) Close() error {
	if s.log != nil {
		return s.log.f.Close()
	}
	return nil
}

func (s *Store) apply(e *Event) {
	s.byID[e.EventID] = e
	c := s.campaigns[e.CampaignID]
	if c == nil {
		c = &campaign{hourly: map[int64]*[4]int{}}
		for i := range c.uniq {
			c.uniq[i] = map[string]struct{}{}
		}
		s.campaigns[e.CampaignID] = c
	}
	ti := typeIndex(e.Type)
	c.raw[ti]++
	c.uniq[ti][e.ContactID] = struct{}{}
	h := e.Timestamp.Truncate(time.Hour).Unix()
	b := c.hourly[h]
	if b == nil {
		b = new([4]int)
		c.hourly[h] = b
	}
	b[ti]++
	if c.first.IsZero() || e.Timestamp.Before(c.first) {
		c.first = e.Timestamp
	}
	if e.Timestamp.After(c.last) {
		c.last = e.Timestamp
	}
	if e.ReceivedAt.After(c.lastRecv) {
		c.lastRecv = e.ReceivedAt
	}
	// Sorted insert; in-order arrival (the common case) appends at the end.
	i := sort.Search(len(c.events), func(i int) bool { return !less(c.events[i], e.Timestamp, e.EventID) })
	c.events = append(c.events, nil)
	copy(c.events[i+1:], c.events[i:])
	c.events[i] = e
}

func less(e *Event, ts time.Time, id string) bool {
	if !e.Timestamp.Equal(ts) {
		return e.Timestamp.Before(ts)
	}
	return e.EventID < id
}

// sameEvent decides whether two events with the same event_id are the same
// event (a retry) or a conflict. Metadata is deliberately ignored: a provider
// re-serialising it must not turn a retry into a conflict.
func sameEvent(a, b *Event) (bool, string) {
	switch {
	case a.CampaignID != b.CampaignID:
		return false, "event_id already used with a different campaign_id"
	case a.ContactID != b.ContactID:
		return false, "event_id already used with a different contact_id"
	case a.Type != b.Type:
		return false, fmt.Sprintf("event_id already used with type %q", a.Type)
	case !a.Timestamp.Equal(b.Timestamp):
		return false, "event_id already used with a different timestamp"
	}
	return true, ""
}

// Ingest applies a batch of already-validated events. results[i] is the
// outcome for evs[i]. The whole batch is one critical section, so concurrent
// batches containing the same event_id can never both be "accepted".
func (s *Store) Ingest(evs []Event, now time.Time) ([]Outcome, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	out := make([]Outcome, len(evs))
	var fresh []*Event
	pending := map[string]*Event{} // earlier events in this same batch
	for i := range evs {
		e := &evs[i]
		e.ReceivedAt = now
		out[i] = Outcome{EventID: e.EventID}
		prev := s.byID[e.EventID]
		if prev == nil {
			prev = pending[e.EventID]
		}
		switch {
		case prev == nil:
			out[i].Status = StatusAccepted
			pending[e.EventID] = e
			fresh = append(fresh, e)
		default:
			if same, why := sameEvent(prev, e); same {
				out[i].Status = StatusDuplicate
			} else {
				out[i].Status = StatusConflict
				out[i].Reason = why
				log.Printf("conflict on %s: %s (kept first)", e.EventID, why)
			}
		}
	}
	if s.log != nil && len(fresh) > 0 {
		if err := s.log.append(fresh); err != nil {
			return nil, err // nothing applied; provider will retry
		}
	}
	for _, e := range fresh {
		s.apply(e)
	}
	return out, nil
}

// ---- reads ----

type TypeCount struct {
	Events         int `json:"events"`          // every accepted event of this type
	UniqueContacts int `json:"unique_contacts"` // distinct contacts with at least one
}

type Totals struct {
	Sent      TypeCount `json:"sent"`
	Delivered TypeCount `json:"delivered"`
	Opened    TypeCount `json:"opened"`
	Clicked   TypeCount `json:"clicked"`
}

type Rates struct {
	DeliveryRate *float64 `json:"delivery_rate"` // unique delivered / unique sent
	OpenRate     *float64 `json:"open_rate"`     // unique opened / unique delivered
	ClickRate    *float64 `json:"click_rate"`    // unique clicked / unique delivered
}

type HourBucket struct {
	Hour      time.Time `json:"hour"`
	Sent      int       `json:"sent"`
	Delivered int       `json:"delivered"`
	Opened    int       `json:"opened"`
	Clicked   int       `json:"clicked"`
}

type Stats struct {
	CampaignID     string       `json:"campaign_id"`
	Totals         Totals       `json:"totals"`
	Rates          Rates        `json:"rates"`
	FirstEventAt   time.Time    `json:"first_event_at"`
	LastEventAt    time.Time    `json:"last_event_at"`
	LastReceivedAt time.Time    `json:"last_received_at"` // freshness: when we last accepted anything
	Hourly         []HourBucket `json:"hourly"`
}

func ratio(a, b int) *float64 {
	if b == 0 {
		return nil
	}
	v := float64(a) / float64(b)
	return &v
}

func (s *Store) Stats(id string) (Stats, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	c := s.campaigns[id]
	if c == nil {
		return Stats{}, false
	}
	tc := func(i int) TypeCount { return TypeCount{c.raw[i], len(c.uniq[i])} }
	st := Stats{
		CampaignID:     id,
		Totals:         Totals{tc(0), tc(1), tc(2), tc(3)},
		FirstEventAt:   c.first,
		LastEventAt:    c.last,
		LastReceivedAt: c.lastRecv,
		Hourly:         make([]HourBucket, 0, len(c.hourly)),
	}
	st.Rates = Rates{
		DeliveryRate: ratio(len(c.uniq[1]), len(c.uniq[0])),
		OpenRate:     ratio(len(c.uniq[2]), len(c.uniq[1])),
		ClickRate:    ratio(len(c.uniq[3]), len(c.uniq[1])),
	}
	hours := make([]int64, 0, len(c.hourly))
	for h := range c.hourly {
		hours = append(hours, h)
	}
	sort.Slice(hours, func(i, j int) bool { return hours[i] < hours[j] })
	for _, h := range hours {
		b := c.hourly[h]
		st.Hourly = append(st.Hourly, HourBucket{time.Unix(h, 0).UTC(), b[0], b[1], b[2], b[3]})
	}
	return st, true
}

// List returns up to limit events, newest first by (timestamp, event_id),
// strictly older than the cursor position if one is given. typ filters by
// event type when non-empty. next is non-nil when more results remain.
func (s *Store) List(id, typ string, limit int, after *cursor) (evs []Event, next *cursor, found bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	c := s.campaigns[id]
	if c == nil {
		return nil, nil, false
	}
	hi := len(c.events)
	if after != nil {
		hi = sort.Search(len(c.events), func(i int) bool { return !less(c.events[i], after.ts, after.id) })
	}
	for i := hi - 1; i >= 0; i-- {
		e := c.events[i]
		if typ != "" && e.Type != typ {
			continue
		}
		if len(evs) == limit {
			last := evs[len(evs)-1]
			return evs, &cursor{last.Timestamp, last.EventID}, true
		}
		evs = append(evs, *e)
	}
	return evs, nil, true
}

// ---- append-only log ----

type eventLog struct {
	f *os.File
	w *bufio.Writer
}

func openLog(path string) (*eventLog, error) {
	f, err := os.OpenFile(path, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0o644)
	if err != nil {
		return nil, err
	}
	// If the previous process died mid-line, start on a fresh line.
	if st, err := f.Stat(); err == nil && st.Size() > 0 {
		b := make([]byte, 1)
		if _, err := f.ReadAt(b, st.Size()-1); err == nil && b[0] != '\n' {
			f.Write([]byte{'\n'})
		}
	}
	return &eventLog{f: f, w: bufio.NewWriter(f)}, nil
}

func (l *eventLog) append(evs []*Event) error {
	for _, e := range evs {
		b, err := json.Marshal(e)
		if err != nil {
			return err
		}
		l.w.Write(b)
		l.w.WriteByte('\n')
	}
	if err := l.w.Flush(); err != nil {
		return err
	}
	return l.f.Sync() // one fsync per batch, not per event
}
